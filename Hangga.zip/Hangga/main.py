def pengendalian_inferensi(SM, TP, KL):
    # Aturan pengendalian inferensi
    if SM > 80 or TP > 90 or KL > 75:
        KKP = "Tinggi"
    elif SM > 70 or TP > 80 or KL > 60:
        KKP = "Sedang"
    else:
        KKP = "Rendah"
    
    return KKP

# Input manual
suhu_mesin = float(input("Masukkan suhu mesin: "))
tekanan_pendingin = float(input("Masukkan tekanan pendingin: "))
kelembaban_lingkungan = float(input("Masukkan kelembaban lingkungan: "))

# Memanggil fungsi pengendalian_inferensi() dengan input manual
kecepatan_kipas = pengendalian_inferensi(suhu_mesin, tekanan_pendingin, kelembaban_lingkungan)

# Menampilkan output
print("Kecepatan Kipas Pendingin: ", kecepatan_kipas)
input("Tekan enter jika sudah sesuai...")